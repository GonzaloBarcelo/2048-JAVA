Juego clasico de 2048

--Reglas

	El fin del juego es tratar de conseguir la máxima puntuación posible. Cada vez que el usuario consigue juntar dos fichas, el valor de las fichas se suma a la puntuación. Solamente podrán sumarse aquellas fichas que tengan el mismo valor, cuando el jugador las haga juntarse usando las flechas. Al irse sumando las fichas, sólo tomarán valores de potencias de dos. En cada movimiento, aparecerá una nueva pieza con el valor más bajo, 2.
	El juego acaba cuando ya no existen movimientos posibles que hacer, cuando se llene la pantalla y ya no queden combinaciones que hacer. La puntuación que haya conseguido el jugador hasta llegar a ese momento será la final. 

--Controles
	Las fichas se podrán mover con los controles clasicos de las flechas del teclado 
	y si el teclado no es ten-keyLess se podrá controlar mediante los números 2(abajo),
	4(izquierda), 6(derecha) y 8 (arriba). 

--Controles adicionales
	Cuando el usuario lo desee, podrá cerrar la pestaña y se almacenará el valor del record actual si asi lo desea el usuario. 




 

